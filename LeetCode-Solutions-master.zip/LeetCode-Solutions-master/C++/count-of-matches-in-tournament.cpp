// Time:  O(1)
// Space: O(1)

class Solution {
public:
    int numberOfMatches(int n) {
        return n - 1;
    }
};
