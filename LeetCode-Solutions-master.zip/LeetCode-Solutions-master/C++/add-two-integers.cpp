// Time:  O(1)
// Space: O(1)

// math
class Solution {
public:
    int sum(int num1, int num2) {
        return num1 + num2;
    }
};
